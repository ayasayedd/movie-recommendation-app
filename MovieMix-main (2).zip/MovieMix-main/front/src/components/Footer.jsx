import styles from '../css/Footer.module.css';

import logoImage from "../assets/M logo 1.png";

function Footer() {
  return (
    <div className={styles.footer}>
      <pre className={styles.pre}>
        M CINEMA © 2021-2022 <span className={styles.span}>Blog Contact Browse Movies Requests Login Language</span>
      </pre>
      <img src={logoImage} alt="Logo" className={styles.logo} />
    </div>
  )
}

export default Footer