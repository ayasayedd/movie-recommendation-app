import React, { useEffect } from 'react';
import '../css/Intro.css';
import logo from '../assets/M logo 1.png';

const IntroScreen = ({ isFading }) => {
  useEffect(() => {

    if (isFading) {
      const timer = setTimeout(() => {
       
      }, 0);
      return () => clearTimeout(timer);
    }
  }, [isFading]);

  return (
<div className={`intro-container ${isFading ? 'fade-out' : ''}`}>
    <img src={logo} alt="App Logo" style={{ width: '200px', marginBottom: '1em' }} />
    </div>
    
  );
};

export default IntroScreen;