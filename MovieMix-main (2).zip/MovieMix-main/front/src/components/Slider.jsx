import React, { useRef, useState, useEffect } from "react";
import "../css/slider.css";
import { useTMDB } from "../hooks/useTMDB";
function SliderItem({ movie }) {
  const imageBaseUrl = "https://image.tmdb.org/t/p/original";
  const backdropPath = movie.backdrop_path;
  const posterPath = movie.poster_path;

  const backgroundImage = backdropPath
    ? `${imageBaseUrl}${backdropPath}`
    : posterPath
    ? `${imageBaseUrl}${posterPath}`
    : "";

  const title = movie.title;
  const overview = movie.overview;

  const truncateOverview = (text, wordLimit = 35) => {
    if (!text) return "";
    const words = text.split(" ");
    if (words.length <= wordLimit) return text;
    return words.slice(0, wordLimit).join(" ") + "...";
  };

  const truncatedOverview = truncateOverview(overview);

  const { getMovieDetails } = useTMDB();

  const handleWatchNow = async () => {
    try {
      const movieDetails = await getMovieDetails(movie.id);
      if (movieDetails?.imdb_id) {
        window.open(`https://www.imdb.com/title/${movieDetails.imdb_id}`, '_blank');
      }
    } catch (error) {
      console.error('Error fetching movie details:', error);
    }
  };

  const handleDetails = () => {
    // Navigate to movie details page
    window.location.href = `/movie/${movie.id}`;
  };

  return (
    <div
      className="item"
      style={{ backgroundImage: `url(${backgroundImage})` }}
    >
      <div className="content">
        <div className="name">{title}</div>
        <div className="title">{truncatedOverview}</div>
        <div className="buttons">
          <button className="slider-btn play-btn" onClick={handleWatchNow}>
            <i className="fa-solid fa-play" />
            <span >Watch Now</span>
          </button>
          <button className="slider-btn info-btn" onClick={handleDetails}>
            <i className="fa-solid fa-info-circle" />
            <span >Details</span>
          </button>
        </div>
      </div>
    </div>
  );
}

const Slider = () => {
  const slideRef = useRef();
  const [touchStartX, setTouchStartX] = useState(0);
  const [touchEndX, setTouchEndX] = useState(0);
  const [trendingMovies, setTrendingMovies] = useState([]);
  const { getTrendingMovies, isLoading, error } = useTMDB();

  useEffect(() => {
    const fetchTrendingMovies = async () => {
      try {
        const data = await getTrendingMovies("week");
        setTrendingMovies(data.results || []);
      } catch (err) {
        console.error("Error fetching trending movies:", err);
      }
    };

    fetchTrendingMovies();
  }, [getTrendingMovies]);

  function goToNext() {
    if (!slideRef.current) return;
    let items = slideRef.current.querySelectorAll(".item");
    if (items.length > 0) {
      slideRef.current.appendChild(items[0]);
    }
  }

  function goToPrevious() {
    if (!slideRef.current) return;
    let items = slideRef.current.querySelectorAll(".item");
    if (items.length > 0) {
      slideRef.current.prepend(items[items.length - 1]);
    }
  }

  function handleTouchStart(e) {
    setTouchStartX(e.touches[0].clientX);
  }

  function handleTouchEnd(e) {
    setTouchEndX(e.changedTouches[0].clientX);
    handleSwipe();
  }

  function handleSwipe() {
    const threshold = 50;
    if (touchStartX - touchEndX > threshold) {
      goToNext();
    } else if (touchEndX - touchStartX > threshold) {
      goToPrevious();
    }
  }

  useEffect(() => {
    const interval = setInterval(() => {
      goToNext();
    }, 15000); 

    return () => clearInterval(interval); 
  }, []);

  if (isLoading) {
    return (
      <div className="container loading-container">
        <div className="loading">Loading trending movies...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container error-container">
        <div className="error">Error loading trending movies: {error}</div>
      </div>
    );
  }

  if (trendingMovies.length === 0) {
    return (
      <div className="container empty-container">
        <div className="empty">No trending movies found</div>
      </div>
    );
  }

  return (
    <>
      <div className="container">
        <div
          className="slide"
          ref={slideRef}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
        >
          {trendingMovies.map((movie) => (
            <SliderItem key={movie.id} movie={movie} />
          ))}
        </div>
        <div className="sliderBTN">
          <button className="prev" onClick={goToPrevious}>
            <i className="fa-solid fa-angle-left sliderBTNButtonI" />
          </button>
          <button className="next" onClick={goToNext}>
            <i className="fa-solid fa-angle-right sliderBTNButtonI" />
          </button>
        </div>
      </div>
    </>
  );
};

export default Slider;
