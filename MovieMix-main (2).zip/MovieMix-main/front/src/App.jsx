import React, { lazy, Suspense, useState, useEffect } from "react";
import ButtonUp from "./components/bottonup";
import "./App.css";
import "./css/utility.css";
import Navbar from "./components/navbar";
import Footer from "./components/Footer";
import IntroScreen from "./components/IntroScreen";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

const HomePage = lazy(() => import("./pages/HomePage"));
const LoginForm = lazy(() => import("./pages/LoginForm"));
const CategoryPage = lazy(() => import("./pages/CategoryPage"));
const MovieDetails = lazy(() => import("./pages/MovieDetails"));

const LoadingFallback = () => (
  <div className="loading-container">
    <div className="loading-spinner"></div>
  </div>
);

function App() {
  const [showIntro, setShowIntro] = useState(true);
  const [fading, setFading] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setFading(true); 
      setTimeout(() => {
        setShowIntro(false);
      }, 1000); 
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      {showIntro ? (
        <IntroScreen isFading={fading} />
      ) : (
        <Router>
          <Navbar />
          <ButtonUp />
          <Suspense fallback={<LoadingFallback />}>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/register" element={<LoginForm />} />
              <Route path="/genre/:genreId" element={<CategoryPage />} />
              <Route path="/movie/:id" element={<MovieDetails />} />
            </Routes>
          </Suspense>
          <Footer />
        </Router>
      )}
    </>
  );
}

export default App;